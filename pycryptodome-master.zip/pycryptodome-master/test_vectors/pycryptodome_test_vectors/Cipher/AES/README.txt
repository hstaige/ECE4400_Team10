Files downloaded from the NIST website on November 8, 2015 as:

* http://csrc.nist.gov/groups/STM/cavp/documents/aes/KAT_AES.zip
* http://csrc.nist.gov/groups/STM/cavp/documents/aes/aesmct.zip
* http://csrc.nist.gov/groups/STM/cavp/documents/aes/aesmmt.zip

Files downloaded on December 16, 2015 as:

* http://csrc.nist.gov/groups/STM/cavp/documents/mac/gcmtestvectors.zip

Files downloaded on November 28, 2022 as:

* https://gitlab.com/dkg/ocb-test-vectors
